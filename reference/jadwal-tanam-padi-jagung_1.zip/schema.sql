-- Skema untuk fitur "Jadwal Tanam" (kalender budidaya per HST)
-- Sumber data: dirangkum dari beberapa referensi penyuluhan (lihat kolom sumber / README)
-- Jalankan di Supabase SQL Editor.

create table if not exists komoditas_jadwal (
  id serial primary key,
  nama text not null unique,             -- 'Padi', 'Jagung', dst
  sistem_tanam text,                     -- mis. 'Sawah irigasi, tanam pindah (tapin)'
  catatan_varietas text
);

create table if not exists kelompok_umur_varietas (
  id serial primary key,
  komoditas_id integer not null references komoditas_jadwal(id),
  nama text not null,                    -- 'genjah' / 'sedang' / 'dalam'
  total_hari_min integer,
  total_hari_max integer,
  satuan text default 'HST',             -- 'HST' atau 'HSS'
  contoh_varietas text
);

create table if not exists fase_budidaya (
  id serial primary key,
  komoditas_id integer not null references komoditas_jadwal(id),
  urutan integer not null,               -- urutan tampil di UI (1..n)
  nama text not null,                    -- 'Persiapan Lahan', 'Semai', dst
  acuan_hst text,                        -- teks bebas, mis. 'HST 0-90an' (durasi pasti dihitung dari sub_kegiatan/durasi_hari)
  durasi_hari integer,                   -- estimasi durasi fase dalam hari (dipakai untuk hitung tanggal di UI)
  kegiatan text
);

create table if not exists sub_kegiatan (
  id serial primary key,
  fase_id integer not null references fase_budidaya(id),
  nama text not null,                    -- 'Pemupukan Susulan I', dst
  hst_mulai integer,                     -- boleh null kalau pakai acuan relatif (mis. 'total-12')
  hst_selesai integer,
  acuan_relatif text,                    -- dipakai kalau hst_mulai/selesai relatif ke total durasi (mis. 'total-12' s.d. 'total-7')
  kegiatan text,
  dosis_acuan text,
  perlu_verifikasi boolean default false -- true kalau angkanya [RENTANG BERVARIASI] antar sumber, tandai di UI sbg "cek PHSL setempat"
);

create table if not exists sumber_referensi (
  id serial primary key,
  komoditas_id integer not null references komoditas_jadwal(id),
  judul text,
  url text
);

create index if not exists idx_kelompok_komoditas on kelompok_umur_varietas(komoditas_id);
create index if not exists idx_fase_komoditas on fase_budidaya(komoditas_id, urutan);
create index if not exists idx_sub_fase on sub_kegiatan(fase_id);

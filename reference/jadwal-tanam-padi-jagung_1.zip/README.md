# Dataset Jadwal Tanam — Padi & Jagung

## Isi paket

- `jadwal_tanam.json` — data mentah (fase, sub-kegiatan, dosis pupuk, sumber referensi)
- `schema.sql` — skema tabel Postgres siap pakai di Supabase (5 tabel: `komoditas_jadwal`, `kelompok_umur_varietas`, `fase_budidaya`, `sub_kegiatan`, `sumber_referensi`)
- `jadwal_tanam.sqlite` — database SQLite hasil load dari JSON, untuk uji coba lokal
- `build_and_validate.py` — script yang memuat JSON ke database, sekaligus validasi

## Cara pakai untuk render layar "Jadwal Tanam" seperti contohmu

Setiap fase punya `durasi_hari` (integer). Untuk dapat tanggal aktual di UI, tinggal jumlahkan berurutan dari tanggal mulai musim tanam yang dipilih user. Saya sudah tes: kalau mulai dari **1 November** (Musim Hujan Nov-Mar, seperti contoh layarmu), hasilnya **persis sama** dengan tampilan yang kamu screenshot:

| Fase | Tanggal |
|---|---|
| Persiapan Lahan | 1–10 Nov |
| Semai | 11–20 Nov |
| Pindah Tanam | 21–30 Nov |
| Pemeliharaan | 1 Des–28 Feb |
| Panen | 1–15 Mar |

Untuk **Jagung**, fasenya cuma 4 (tidak ada Semai/Pindah Tanam karena jagung ditanam langsung/tugal, bukan disemai dulu): Persiapan Lahan → Tanam → Pemeliharaan → Panen. Jadi UI-nya perlu tampilkan jumlah tahapan yang beda tergantung komoditas — bukan selalu 5 tahap seperti padi.

Di dalam fase **Pemeliharaan**, ada `sub_kegiatan` (pemupukan susulan I/II, penyiangan, pemantauan OPT, dst) dengan `hst_mulai`/`hst_selesai` sendiri — ini yang jawab pertanyaanmu soal "kapan pemeliharaan, kapan pupuk": bukan satu blok pemeliharaan yang polos, tapi ada event-event kecil di dalamnya yang masing-masing bisa dimunculkan sebagai notifikasi/pengingat terpisah ke petani (mis. "Hari ini saatnya pemupukan susulan I").

## PENTING — soal akurasi data ini

Beda dengan database pestisida Kementan yang satu sumber resmi, data jadwal tanam ini saya rangkum dari **beberapa sumber sekunder** (artikel dinas pertanian, IPB Digitani, BPPSDMP/BRMP, dan beberapa blog pertanian) karena tidak ada satu database terbuka resmi untuk kalender budidaya per-HST seperti pestisida tadi. Beberapa angka HST antar sumber **tidak selalu sama** (saya tandai dengan `perlu_verifikasi = true` di tabel `sub_kegiatan` / `[RENTANG BERVARIASI]` di JSON) — terutama:

- Padi: pemupukan susulan I disebut 7 HST oleh satu sumber, 10-15 HST oleh sumber lain
- Padi: pemupukan susulan II disebut 25-30 HST oleh satu sumber, ada juga yang bilang bisa sampai 35-40 HST
- Jagung: umur panen disebut 80-110 HST di satu sumber (dokumen resmi Badan Riset & Pengembangan Pertanian), tapi 120 HST di sumber lain

Dosis pupuk yang saya cantumkan juga sifatnya **patokan umum**, bukan pengganti PHSL (Pemupukan Hara Spesifik Lokasi)/uji tanah. Karena kamu penyuluh yang punya pengalaman lapangan langsung, saran saya: pakai dataset ini sebagai draf awal/kerangka, lalu koreksi angka-angka yang saya tandai perlu-verifikasi itu berdasarkan juknis resmi BPP/dinas setempat atau pengalamanmu sendiri, sebelum dipakai sebagai anjuran final ke petani — supaya tidak keliru dan berisiko ke hasil panen mereka.

Sumber yang saya pakai ada di field `sumber_referensi` / bagian akhir `jadwal_tanam.json`.

## Belum termasuk

Kedelai dan Cabai (yang juga muncul di filter komoditas layar "Lahan Saya"-mu) belum saya buatkan — kasih tahu kalau mau saya lanjutkan riset untuk keduanya juga.
